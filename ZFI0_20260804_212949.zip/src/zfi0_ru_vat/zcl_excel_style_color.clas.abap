class ZCL_EXCEL_STYLE_COLOR definition
  public
  final
  create public .

public section.

  constants C_BLACK type ZEXCEL_STYLE_COLOR_ARGB value 'FF000000' ##NO_TEXT.
  constants C_BLUE type ZEXCEL_STYLE_COLOR_ARGB value 'FF0000FF' ##NO_TEXT.
  constants C_DARKBLUE type ZEXCEL_STYLE_COLOR_ARGB value 'FF000080' ##NO_TEXT.
  constants C_DARKGREEN type ZEXCEL_STYLE_COLOR_ARGB value 'FF008000' ##NO_TEXT.
  constants C_DARKRED type ZEXCEL_STYLE_COLOR_ARGB value 'FF800000' ##NO_TEXT.
  constants C_DARKYELLOW type ZEXCEL_STYLE_COLOR_ARGB value 'FF808000' ##NO_TEXT.
  constants C_GRAY type ZEXCEL_STYLE_COLOR_ARGB value 'FFCCCCCC' ##NO_TEXT.
  constants C_GREEN type ZEXCEL_STYLE_COLOR_ARGB value 'FF00FF00' ##NO_TEXT.
  constants C_RED type ZEXCEL_STYLE_COLOR_ARGB value 'FFFF0000' ##NO_TEXT.
  constants C_WHITE type ZEXCEL_STYLE_COLOR_ARGB value 'FFFFFFFF' ##NO_TEXT.
  constants C_YELLOW type ZEXCEL_STYLE_COLOR_ARGB value 'FFFFFF00' ##NO_TEXT.
  constants C_PALEYELLOW type ZEXCEL_STYLE_COLOR_ARGB value 'FFFFFAC8' ##NO_TEXT.
  constants C_PALEGREEN type ZEXCEL_STYLE_COLOR_ARGB value 'FFE2FFCD' ##NO_TEXT.
  constants C_PALEBLUE type ZEXCEL_STYLE_COLOR_ARGB value 'FFCAE6FF' ##NO_TEXT.
  constants C_PALERED type ZEXCEL_STYLE_COLOR_ARGB value 'FFFFC5C5' ##NO_TEXT.
  constants C_THEME_DARK1 type ZEXCEL_STYLE_COLOR_THEME value 0 ##NO_TEXT.
  constants C_THEME_LIGHT1 type ZEXCEL_STYLE_COLOR_THEME value 1 ##NO_TEXT.
  constants C_THEME_DARK2 type ZEXCEL_STYLE_COLOR_THEME value 2 ##NO_TEXT.
  constants C_THEME_LIGHT2 type ZEXCEL_STYLE_COLOR_THEME value 3 ##NO_TEXT.
  constants C_THEME_ACCENT1 type ZEXCEL_STYLE_COLOR_THEME value 4 ##NO_TEXT.
  constants C_THEME_ACCENT2 type ZEXCEL_STYLE_COLOR_THEME value 5 ##NO_TEXT.
  constants C_THEME_ACCENT3 type ZEXCEL_STYLE_COLOR_THEME value 6 ##NO_TEXT.
  constants C_THEME_ACCENT4 type ZEXCEL_STYLE_COLOR_THEME value 7 ##NO_TEXT.
  constants C_THEME_ACCENT5 type ZEXCEL_STYLE_COLOR_THEME value 8 ##NO_TEXT.
  constants C_THEME_ACCENT6 type ZEXCEL_STYLE_COLOR_THEME value 9 ##NO_TEXT.
  constants C_THEME_HYPERLINK type ZEXCEL_STYLE_COLOR_THEME value 10 ##NO_TEXT.
  constants C_THEME_HYPERLINK_FOLLOWED type ZEXCEL_STYLE_COLOR_THEME value 11 ##NO_TEXT.
  constants C_THEME_NOT_SET type ZEXCEL_STYLE_COLOR_THEME value -1 ##NO_TEXT.
  constants C_INDEXED_NOT_SET type ZEXCEL_STYLE_COLOR_INDEXED value -1 ##NO_TEXT.
  constants C_INDEXED_SYS_FOREGROUND type ZEXCEL_STYLE_COLOR_INDEXED value 64 ##NO_TEXT.

  class-methods CREATE_NEW_ARGB
    importing
      !IP_RED type ZEXCEL_STYLE_COLOR_COMPONENT
      !IP_GREEN type ZEXCEL_STYLE_COLOR_COMPONENT
      !IP_BLU type ZEXCEL_STYLE_COLOR_COMPONENT
    returning
      value(EP_COLOR_ARGB) type ZEXCEL_STYLE_COLOR_ARGB .
  class-methods CREATE_NEW_ARBG_INT
    importing
      !IV_RED type NUMERIC
      !IV_GREEN type NUMERIC
      !IV_BLUE type NUMERIC
    returning
      value(RV_COLOR_ARGB) type ZEXCEL_STYLE_COLOR_ARGB .
protected section.
private section.

  constants C_ALPHA type CHAR2 value 'FF' ##NO_TEXT.
ENDCLASS.



CLASS ZCL_EXCEL_STYLE_COLOR IMPLEMENTATION.


METHOD create_new_arbg_int.
  DATA: lv_red        TYPE int1,
        lv_green      TYPE int1,
        lv_blue       TYPE int1,
        lv_hex        TYPE x,
        lv_char_red   TYPE zexcel_style_color_component,
        lv_char_green TYPE zexcel_style_color_component,
        lv_char_blue  TYPE zexcel_style_color_component.

  lv_red    = iv_red MOD 256.
  lv_green  = iv_green MOD 256.
  lv_blue   = iv_blue  MOD 256.

  lv_hex        = lv_red.
  lv_char_red   = lv_hex.

  lv_hex        = lv_green.
  lv_char_green = lv_hex.

  lv_hex        = lv_blue.
  lv_char_blue  = lv_hex.


  concatenate zcl_excel_style_color=>c_alpha lv_char_red lv_char_green lv_char_blue into rv_color_argb.


ENDMETHOD.


METHOD create_new_argb.

  CONCATENATE zcl_excel_style_color=>c_alpha ip_red ip_green ip_blu INTO ep_color_argb.

ENDMETHOD.
ENDCLASS.
