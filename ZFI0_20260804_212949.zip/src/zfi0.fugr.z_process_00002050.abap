FUNCTION Z_PROCESS_00002050.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_REGUH) LIKE  REGUH STRUCTURE  REGUH
*"     VALUE(I_GJAHR) LIKE  REGUD-GJAHR
*"     VALUE(I_NACHA) LIKE  FINAA-NACHA
*"     VALUE(I_AFORN) LIKE  T042B-AFORN
*"  CHANGING
*"     VALUE(C_ITCPO) LIKE  ITCPO STRUCTURE  ITCPO
*"     VALUE(C_ARCHIVE_INDEX) LIKE  TOA_DARA STRUCTURE  TOA_DARA
*"       DEFAULT SPACE
*"     VALUE(C_ARCHIVE_PARAMS) LIKE  ARC_PARAMS STRUCTURE  ARC_PARAMS
*"       DEFAULT SPACE
*"----------------------------------------------------------------------
DATA: EX_DATE(10) TYPE C.
data: lif(10) type c.
CLEAR EX_DATE.
if i_nacha eq 'I'.
  CONCATENATE I_REGUH-laufd+6(2) '.' I_REGUH-laufd+4(2) '.'
   I_REGUH-laufd+0(4) INTO EX_DATE.
   lif = I_REGUH-lifnr.
   SHIFT lif LEFT DELETING LEADING '0'.
   concatenate 'Payment advice note from:' EX_DATE '/'
  lif INTO C_ITCPO-tdtitle.
endif.




ENDFUNCTION.
