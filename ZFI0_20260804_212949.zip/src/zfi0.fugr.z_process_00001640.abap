FUNCTION z_process_00001640.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(I_REGUH) LIKE  REGUH STRUCTURE  REGUH OPTIONAL
*"  TABLES
*"      T_REGUP STRUCTURE  REGUP
*"      T_HEADER STRUCTURE  FNAMEVALUE OPTIONAL
*"      T_ITEM_BANK STRUCTURE  FNAMEVALUE OPTIONAL
*"      T_ITEM_CLEARING STRUCTURE  FNAMEVALUE OPTIONAL
*"----------------------------------------------------------------------







ENDFUNCTION.
