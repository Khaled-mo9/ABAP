FUNCTION-POOL ZPP_DISPO2                 MESSAGE-ID SV.

* INCLUDE LZPP_DISPO2D...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZPP_DISPO2T00                          . "view rel. data dcl.
