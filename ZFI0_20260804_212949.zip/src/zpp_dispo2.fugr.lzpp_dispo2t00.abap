*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZT024D..........................................*
DATA:  BEGIN OF STATUS_ZT024D                        .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZT024D                        .
CONTROLS: TCTRL_ZT024D
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZT024D                        .
TABLES: ZT024D                         .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
