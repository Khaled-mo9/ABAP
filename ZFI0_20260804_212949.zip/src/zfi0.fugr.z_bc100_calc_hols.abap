FUNCTION Z_BC100_CALC_HOLS.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_TOTAL) TYPE  I
*"     REFERENCE(IV_USED) TYPE  I
*"  EXPORTING
*"     REFERENCE(EV_REMAINING) TYPE  I
*"----------------------------------------------------------------------

ev_remaining = iv_total - iv_used.




ENDFUNCTION.
