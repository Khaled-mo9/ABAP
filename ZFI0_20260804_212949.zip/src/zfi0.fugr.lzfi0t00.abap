*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZBPC_ME.........................................*
DATA:  BEGIN OF STATUS_ZBPC_ME                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBPC_ME                       .
CONTROLS: TCTRL_ZBPC_ME
            TYPE TABLEVIEW USING SCREEN '0024'.
*...processing: ZBP_CAS.........................................*
DATA:  BEGIN OF STATUS_ZBP_CAS                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBP_CAS                       .
CONTROLS: TCTRL_ZBP_CAS
            TYPE TABLEVIEW USING SCREEN '0025'.
*...processing: ZCO_CHANNEL_DE..................................*
DATA:  BEGIN OF STATUS_ZCO_CHANNEL_DE                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCO_CHANNEL_DE                .
CONTROLS: TCTRL_ZCO_CHANNEL_DE
            TYPE TABLEVIEW USING SCREEN '0032'.
*...processing: ZCO_CHANNEL_FR..................................*
DATA:  BEGIN OF STATUS_ZCO_CHANNEL_FR                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCO_CHANNEL_FR                .
CONTROLS: TCTRL_ZCO_CHANNEL_FR
            TYPE TABLEVIEW USING SCREEN '0031'.
*...processing: ZCO_CHANNEL_IT..................................*
DATA:  BEGIN OF STATUS_ZCO_CHANNEL_IT                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCO_CHANNEL_IT                .
CONTROLS: TCTRL_ZCO_CHANNEL_IT
            TYPE TABLEVIEW USING SCREEN '0036'.
*...processing: ZCO_CHANNEL_UK..................................*
DATA:  BEGIN OF STATUS_ZCO_CHANNEL_UK                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCO_CHANNEL_UK                .
CONTROLS: TCTRL_ZCO_CHANNEL_UK
            TYPE TABLEVIEW USING SCREEN '0034'.
*...processing: ZCO_GLOB_CHANNEL................................*
DATA:  BEGIN OF STATUS_ZCO_GLOB_CHANNEL              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCO_GLOB_CHANNEL              .
CONTROLS: TCTRL_ZCO_GLOB_CHANNEL
            TYPE TABLEVIEW USING SCREEN '0005'.
*...processing: ZCO_UK_CHANNEL_L................................*
DATA:  BEGIN OF STATUS_ZCO_UK_CHANNEL_L              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCO_UK_CHANNEL_L              .
CONTROLS: TCTRL_ZCO_UK_CHANNEL_L
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZFI_CONSOLID....................................*
DATA:  BEGIN OF STATUS_ZFI_CONSOLID                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CONSOLID                  .
CONTROLS: TCTRL_ZFI_CONSOLID
            TYPE TABLEVIEW USING SCREEN '0023'.
*...processing: ZFI_CONSOLID_AA.................................*
DATA:  BEGIN OF STATUS_ZFI_CONSOLID_AA               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CONSOLID_AA               .
CONTROLS: TCTRL_ZFI_CONSOLID_AA
            TYPE TABLEVIEW USING SCREEN '0015'.
*...processing: ZFI_CONSOLID_AGE................................*
DATA:  BEGIN OF STATUS_ZFI_CONSOLID_AGE              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CONSOLID_AGE              .
CONTROLS: TCTRL_ZFI_CONSOLID_AGE
            TYPE TABLEVIEW USING SCREEN '0013'.
*...processing: ZFI_CONSOLID_EXC................................*
DATA:  BEGIN OF STATUS_ZFI_CONSOLID_EXC              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CONSOLID_EXC              .
CONTROLS: TCTRL_ZFI_CONSOLID_EXC
            TYPE TABLEVIEW USING SCREEN '0012'.
*...processing: ZFI_CONSOLID_HYP................................*
DATA:  BEGIN OF STATUS_ZFI_CONSOLID_HYP              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CONSOLID_HYP              .
CONTROLS: TCTRL_ZFI_CONSOLID_HYP
            TYPE TABLEVIEW USING SCREEN '0009'.
*...processing: ZFI_CONSOLID_SUM................................*
DATA:  BEGIN OF STATUS_ZFI_CONSOLID_SUM              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CONSOLID_SUM              .
CONTROLS: TCTRL_ZFI_CONSOLID_SUM
            TYPE TABLEVIEW USING SCREEN '0014'.
*...processing: ZFI_CONSOLID_TC.................................*
DATA:  BEGIN OF STATUS_ZFI_CONSOLID_TC               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_CONSOLID_TC               .
CONTROLS: TCTRL_ZFI_CONSOLID_TC
            TYPE TABLEVIEW USING SCREEN '0010'.
*...processing: ZFI_EC_SUPPLMAIL................................*
DATA:  BEGIN OF STATUS_ZFI_EC_SUPPLMAIL              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_EC_SUPPLMAIL              .
CONTROLS: TCTRL_ZFI_EC_SUPPLMAIL
            TYPE TABLEVIEW USING SCREEN '0022'.
*...processing: ZFI_EC_SUPPL_TAX................................*
DATA:  BEGIN OF STATUS_ZFI_EC_SUPPL_TAX              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_EC_SUPPL_TAX              .
CONTROLS: TCTRL_ZFI_EC_SUPPL_TAX
            TYPE TABLEVIEW USING SCREEN '0020'.
*...processing: ZFI_IT_EATCH_DT.................................*
DATA:  BEGIN OF STATUS_ZFI_IT_EATCH_DT               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_IT_EATCH_DT               .
CONTROLS: TCTRL_ZFI_IT_EATCH_DT
            TYPE TABLEVIEW USING SCREEN '0028'.
*...processing: ZFI_SUBST_BVTYP.................................*
DATA:  BEGIN OF STATUS_ZFI_SUBST_BVTYP               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_SUBST_BVTYP               .
CONTROLS: TCTRL_ZFI_SUBST_BVTYP
            TYPE TABLEVIEW USING SCREEN '0021'.
*...processing: ZFI_SUBST_VBUND.................................*
DATA:  BEGIN OF STATUS_ZFI_SUBST_VBUND               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_SUBST_VBUND               .
CONTROLS: TCTRL_ZFI_SUBST_VBUND
            TYPE TABLEVIEW USING SCREEN '0026'.
*...processing: ZFI_TAX_XFLOW...................................*
DATA:  BEGIN OF STATUS_ZFI_TAX_XFLOW                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_TAX_XFLOW                 .
CONTROLS: TCTRL_ZFI_TAX_XFLOW
            TYPE TABLEVIEW USING SCREEN '0016'.
*...processing: ZFI_UNBLOCK_LOG.................................*
DATA:  BEGIN OF STATUS_ZFI_UNBLOCK_LOG               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_UNBLOCK_LOG               .
CONTROLS: TCTRL_ZFI_UNBLOCK_LOG
            TYPE TABLEVIEW USING SCREEN '0017'.
*...processing: ZFI_VEND_PBLOCK.................................*
DATA:  BEGIN OF STATUS_ZFI_VEND_PBLOCK               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFI_VEND_PBLOCK               .
CONTROLS: TCTRL_ZFI_VEND_PBLOCK
            TYPE TABLEVIEW USING SCREEN '0003'.
*...processing: ZJ3RF_PLAT_TAX..................................*
DATA:  BEGIN OF STATUS_ZJ3RF_PLAT_TAX                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZJ3RF_PLAT_TAX                .
CONTROLS: TCTRL_ZJ3RF_PLAT_TAX
            TYPE TABLEVIEW USING SCREEN '0008'.
*...processing: ZJPKKOIS_CORR...................................*
DATA:  BEGIN OF STATUS_ZJPKKOIS_CORR                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZJPKKOIS_CORR                 .
CONTROLS: TCTRL_ZJPKKOIS_CORR
            TYPE TABLEVIEW USING SCREEN '0030'.
*...processing: ZRU_TORG12_CONTR................................*
DATA:  BEGIN OF STATUS_ZRU_TORG12_CONTR              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZRU_TORG12_CONTR              .
CONTROLS: TCTRL_ZRU_TORG12_CONTR
            TYPE TABLEVIEW USING SCREEN '0029'.
*...processing: ZSD_LAUNCHDATE..................................*
DATA:  BEGIN OF STATUS_ZSD_LAUNCHDATE                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSD_LAUNCHDATE                .
CONTROLS: TCTRL_ZSD_LAUNCHDATE
            TYPE TABLEVIEW USING SCREEN '0035'.
*...processing: ZSEPA_BUKRS.....................................*
DATA:  BEGIN OF STATUS_ZSEPA_BUKRS                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSEPA_BUKRS                   .
CONTROLS: TCTRL_ZSEPA_BUKRS
            TYPE TABLEVIEW USING SCREEN '0019'.
*...processing: ZTE_BUKRS_COST_A................................*
DATA:  BEGIN OF STATUS_ZTE_BUKRS_COST_A              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTE_BUKRS_COST_A              .
CONTROLS: TCTRL_ZTE_BUKRS_COST_A
            TYPE TABLEVIEW USING SCREEN '0027'.
*...processing: ZTRM_POWL_SUBS..................................*
TABLES: ZTRM_POWL_SUBS, *ZTRM_POWL_SUBS. "view work areas
CONTROLS: TCTRL_ZTRM_POWL_SUBS
TYPE TABLEVIEW USING SCREEN '1011'.
DATA: BEGIN OF STATUS_ZTRM_POWL_SUBS. "state vector
          INCLUDE STRUCTURE VIMSTATUS.
DATA: END OF STATUS_ZTRM_POWL_SUBS.
* Table for entries selected to show on screen
DATA: BEGIN OF ZTRM_POWL_SUBS_EXTRACT OCCURS 0010.
INCLUDE STRUCTURE ZTRM_POWL_SUBS.
          INCLUDE STRUCTURE VIMFLAGTAB.
DATA: END OF ZTRM_POWL_SUBS_EXTRACT.
* Table for all entries loaded from database
DATA: BEGIN OF ZTRM_POWL_SUBS_TOTAL OCCURS 0010.
INCLUDE STRUCTURE ZTRM_POWL_SUBS.
          INCLUDE STRUCTURE VIMFLAGTAB.
DATA: END OF ZTRM_POWL_SUBS_TOTAL.

*...processing: ZVMDM_DFLT......................................*
DATA:  BEGIN OF STATUS_ZVMDM_DFLT                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVMDM_DFLT                    .
CONTROLS: TCTRL_ZVMDM_DFLT
            TYPE TABLEVIEW USING SCREEN '0007'.
*...processing: ZVMDM_RULES.....................................*
DATA:  BEGIN OF STATUS_ZVMDM_RULES                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVMDM_RULES                   .
CONTROLS: TCTRL_ZVMDM_RULES
            TYPE TABLEVIEW USING SCREEN '0002'.
*...processing: ZVMDM_VPTC......................................*
DATA:  BEGIN OF STATUS_ZVMDM_VPTC                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZVMDM_VPTC                    .
CONTROLS: TCTRL_ZVMDM_VPTC
            TYPE TABLEVIEW USING SCREEN '0004'.
*...processing: ZV_CONTRACT_INFO................................*
TABLES: ZV_CONTRACT_INFO, *ZV_CONTRACT_INFO. "view work areas
CONTROLS: TCTRL_ZV_CONTRACT_INFO
TYPE TABLEVIEW USING SCREEN '0018'.
DATA: BEGIN OF STATUS_ZV_CONTRACT_INFO. "state vector
          INCLUDE STRUCTURE VIMSTATUS.
DATA: END OF STATUS_ZV_CONTRACT_INFO.
* Table for entries selected to show on screen
DATA: BEGIN OF ZV_CONTRACT_INFO_EXTRACT OCCURS 0010.
INCLUDE STRUCTURE ZV_CONTRACT_INFO.
          INCLUDE STRUCTURE VIMFLAGTAB.
DATA: END OF ZV_CONTRACT_INFO_EXTRACT.
* Table for all entries loaded from database
DATA: BEGIN OF ZV_CONTRACT_INFO_TOTAL OCCURS 0010.
INCLUDE STRUCTURE ZV_CONTRACT_INFO.
          INCLUDE STRUCTURE VIMFLAGTAB.
DATA: END OF ZV_CONTRACT_INFO_TOTAL.

*.........table declarations:.................................*
TABLES: *ZBPC_ME                       .
TABLES: *ZBP_CAS                       .
TABLES: *ZCO_CHANNEL_DE                .
TABLES: *ZCO_CHANNEL_FR                .
TABLES: *ZCO_CHANNEL_IT                .
TABLES: *ZCO_CHANNEL_UK                .
TABLES: *ZCO_GLOB_CHANNEL              .
TABLES: *ZCO_UK_CHANNEL_L              .
TABLES: *ZFI_CONSOLID                  .
TABLES: *ZFI_CONSOLID_AA               .
TABLES: *ZFI_CONSOLID_AGE              .
TABLES: *ZFI_CONSOLID_EXC              .
TABLES: *ZFI_CONSOLID_HYP              .
TABLES: *ZFI_CONSOLID_SUM              .
TABLES: *ZFI_CONSOLID_TC               .
TABLES: *ZFI_EC_SUPPLMAIL              .
TABLES: *ZFI_EC_SUPPL_TAX              .
TABLES: *ZFI_IT_EATCH_DT               .
TABLES: *ZFI_SUBST_BVTYP               .
TABLES: *ZFI_SUBST_VBUND               .
TABLES: *ZFI_TAX_XFLOW                 .
TABLES: *ZFI_UNBLOCK_LOG               .
TABLES: *ZFI_VEND_PBLOCK               .
TABLES: *ZJ3RF_PLAT_TAX                .
TABLES: *ZJPKKOIS_CORR                 .
TABLES: *ZRU_TORG12_CONTR              .
TABLES: *ZSD_LAUNCHDATE                .
TABLES: *ZSEPA_BUKRS                   .
TABLES: *ZTE_BUKRS_COST_A              .
TABLES: *ZVMDM_DFLT                    .
TABLES: *ZVMDM_RULES                   .
TABLES: *ZVMDM_VPTC                    .
TABLES: PTRM_POWL_SUBS_R               .
TABLES: T001                           .
TABLES: ZBPC_ME                        .
TABLES: ZBP_CAS                        .
TABLES: ZCONTRCT_INFO_IT               .
TABLES: ZCO_CHANNEL_DE                 .
TABLES: ZCO_CHANNEL_FR                 .
TABLES: ZCO_CHANNEL_IT                 .
TABLES: ZCO_CHANNEL_UK                 .
TABLES: ZCO_GLOB_CHANNEL               .
TABLES: ZCO_UK_CHANNEL_L               .
TABLES: ZFI_CONSOLID                   .
TABLES: ZFI_CONSOLID_AA                .
TABLES: ZFI_CONSOLID_AGE               .
TABLES: ZFI_CONSOLID_EXC               .
TABLES: ZFI_CONSOLID_HYP               .
TABLES: ZFI_CONSOLID_SUM               .
TABLES: ZFI_CONSOLID_TC                .
TABLES: ZFI_EC_SUPPLMAIL               .
TABLES: ZFI_EC_SUPPL_TAX               .
TABLES: ZFI_IT_EATCH_DT                .
TABLES: ZFI_SUBST_BVTYP                .
TABLES: ZFI_SUBST_VBUND                .
TABLES: ZFI_TAX_XFLOW                  .
TABLES: ZFI_UNBLOCK_LOG                .
TABLES: ZFI_VEND_PBLOCK                .
TABLES: ZJ3RF_PLAT_TAX                 .
TABLES: ZJPKKOIS_CORR                  .
TABLES: ZRU_TORG12_CONTR               .
TABLES: ZSD_LAUNCHDATE                 .
TABLES: ZSEPA_BUKRS                    .
TABLES: ZTE_BUKRS_COST_A               .
TABLES: ZVMDM_DFLT                     .
TABLES: ZVMDM_RULES                    .
TABLES: ZVMDM_VPTC                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
