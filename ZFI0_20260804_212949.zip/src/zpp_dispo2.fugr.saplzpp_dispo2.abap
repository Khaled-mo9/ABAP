*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZPP_DISPO2TOP.                    " Global Data
  INCLUDE LZPP_DISPO2UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZPP_DISPO2F...                    " Subroutines
* INCLUDE LZPP_DISPO2O...                    " PBO-Modules
* INCLUDE LZPP_DISPO2I...                    " PAI-Modules
* INCLUDE LZPP_DISPO2E...                    " Events
* INCLUDE LZPP_DISPO2P...                    " Local class implement.
  INCLUDE LZPP_DISPO2F00                          . " subprograms
  INCLUDE LZPP_DISPO2I00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
