FUNCTION Z_MAIL_00002040.
*"----------------------------------------------------------------------
*"*"Local interface:
*"  IMPORTING
*"     VALUE(I_REGUH) LIKE  REGUH STRUCTURE  REGUH
*"  TABLES
*"      T_FIMSG STRUCTURE  FIMSG
*"  CHANGING
*"     VALUE(C_FINAA) LIKE  FINAA STRUCTURE  FINAA
*"----------------------------------------------------------------------

* data declaration for address routines
  TYPE-POOLS szadr.
  DATA: l_addr1_complete TYPE szadr_addr1_complete,
        l_adsmtp_line    TYPE szadr_adsmtp_line.


** check that address number is available
*  IF NOT i_reguh-zadnr IS INITIAL.
**   read complete address of vendor/customer
*    CALL FUNCTION 'ADDR_GET_COMPLETE'
*         EXPORTING
*              addrnumber     = i_reguh-zadnr
*         IMPORTING
*              addr1_complete = l_addr1_complete
*         EXCEPTIONS
*              OTHERS         = 4.
*    IF sy-subrc EQ 0.
**     check that internet address is available
*      READ TABLE l_addr1_complete-adsmtp_tab INTO l_adsmtp_line INDEX 1.
*      IF sy-subrc EQ 0
*      AND NOT l_adsmtp_line-adsmtp-smtp_addr IS INITIAL.
**       choose message type 'I'nternet and fill email address
*        c_finaa-nacha = 'I'.
*        c_finaa-intad = l_adsmtp_line-adsmtp-smtp_addr.
*      ENDIF.
*    ENDIF.
*  ENDIF.

if NOT i_reguh-lifnr IS INITIAL and NOT i_reguh-zbukr IS INITIAL.
select single INTAD from lfb1 into c_finaa-intad
  where lifnr eq i_reguh-lifnr
    and bukrs eq i_reguh-zbukr.
    c_finaa-nacha = 'I'.
endif.




ENDFUNCTION.
