*&---------------------------------------------------------------------*
*&  Include           ZSDI_EINV_EINVOICE_TOP
*&---------------------------------------------------------------------*

""""" DATA DECLARATIONS .
DATA : message TYPE string.
DATA : any TYPE zsd_inv_invoices.
DATA : types TYPE RANGE OF kschl.
"GET DETAILS
TYPES : BEGIN OF st_innererror,
          propertyName TYPE string,
          error        TYPE string,
        END OF st_innererror.
DATA : innererrors TYPE TABLE OF st_innererror,
       innererror  TYPE st_innererror.
TYPES : BEGIN OF error,
          error      TYPE string,
          innerError LIKE innererrors,
        END OF error.
TYPES : BEGIN OF validationSteps,
          status   TYPE string,
          error    TYPE error,
          stepName TYPE string,
          stepId   TYPE string,
        END OF validationSteps.
DATA : validations TYPE TABLE OF validationSteps,
       validation  LIKE LINE OF validations,
       invalids    LIKE validation-error-innererror.
TYPES : BEGIN OF validationResults,
          status          TYPE string,
          validationSteps LIKE validations,
        END OF validationResults.
TYPES : BEGIN OF details,
          status            TYPE string,
          validationResults TYPE validationResults,
        END OF details.
DATA : details TYPE details.
"""""""""""""""""""""""""""

DATA : extra_discount_amount       TYPE p DECIMALS 5,
       total_items_discount_amount TYPE p DECIMALS 5,
       total_discount_amount       TYPE p DECIMALS 5.

DATA : stoken TYPE zsd_abap_st_stoken,
       etoken TYPE zsd_abap_st_etoken.

DATA :
  submission   TYPE zsd_abap_st_esubmit,
  acc_doc      LIKE LINE OF submission-accepteddocuments,
  rej_doc      LIKE LINE OF submission-rejecteddocuments,
  detail_error TYPE ZSD_ABAP_sT_ERRORD. "esraa added
DATA : invoice TYPE zsd_inv_invoices.
"Client ID-Secret
DATA : id     TYPE string,
       secret TYPE string.
"ALV OUTPUT
TYPES : BEGIN OF output ,
          selct           TYPE char1,
          icon_d          TYPE icon_d,
          vbeln           TYPE vbeln,
          bukrs           TYPE bukrs,
          butxt           TYPE butxt,
          kunrg           TYPE kunrg,
          waerk           TYPE waerk,
          type            TYPE bu_id_type , " commented by mosbah 4-12-2022
*        IDNUMBER  TYPE BU_ID_NUMBER, " commented by mosbah 4-12-2022
          idnumber        TYPE stcd1,
          name1           TYPE name1_gp,
          doc_desc        TYPE char40,
          document_type   TYPE char21,
          country         TYPE char2,
          status          TYPE char20,
          uuid            TYPE string,
          submissionid    TYPE string,
          vbtyp           TYPE vbtyp,
          sales_total     TYPE netwr,
          net_total       TYPE netwr,
          tax             TYPE netwr,
          total           TYPE netwr,
          discount        TYPE netwr,
          extra_discount  TYPE netwr,
          fkdat           TYPE datum,
          submission_date TYPE datum,
          cancel          TYPE cancel,
          fksto           TYPE fksto,
          vtweg           TYPE vtweg,
          fkart           TYPE fkart,
          vbelv           TYPE vbfa-vbelv,
          vbelv_1         TYPE vbfa-vbelv,
          vbelv_2         TYPE vbfa-vbelv,
          erzet           TYPE   erzet, " added 10-03-2023
          erdat	          TYPE erdat,
          kunnr_1	        TYPE kunnr,
          kunnr_2	        TYPE kunnr,
          kunnr	          TYPE kunnr,
          land1_2         TYPE land1_gp,
          name1_2         TYPE name1_gp,
          stcd1_2         TYPE stcd1,
          type_cust       TYPE zsd_cust_numbers-type,
        END OF output .
DATA : it TYPE TABLE OF output,
       wa TYPE output.
DATA:  rv_json TYPE string. """"" JSON FORMAT
DATA:  x_json  TYPE xstring. """"" JSON FORMAT
DATA: it_fieldcat TYPE lvc_t_fcat,
      wa_fieldcat TYPE lvc_s_fcat,
      layout      TYPE lvc_s_layo.
DATA : it_header TYPE slis_t_listheader,
       wa_header LIKE LINE OF it_header.

"JSON FILE
DATA :
  wa_doc   TYPE zsd_abap_st_edocument,
  inv_sign TYPE string,
  inv_canc TYPE string.
DATA : WA_DOC_Export TYPE zsd_abap_st_edocument_e.

"HTTP CLIENT
DATA : url         TYPE string,
       http_client TYPE REF TO if_http_client,
       cl_idsec    TYPE string,
       response    TYPE string,
       reason      TYPE string,
       st_code     TYPE i,
       lo_httputil TYPE REF TO cl_http_utility,
       "HEADER
       head_fields TYPE tihttpnvp,
       head_field  TYPE LINE OF tihttpnvp,
       http_method TYPE string,
       http_name   TYPE string,
       http_value  TYPE string,
       http_data   TYPE string,
       "FORM
       http_fields TYPE tihttpnvp,
       http_field  LIKE LINE OF http_fields.

CREATE OBJECT lo_httputil TYPE cl_http_utility.
"INVOICE LINES
TYPES : BEGIN OF invoice,
          description   TYPE char255,
          unit_type     TYPE char255,
          internal_code TYPE char255,
          quantity      TYPE p DECIMALS 5,
          item_code     TYPE string,
          posnr         TYPE posnr,
          numtp         TYPE numtp,
        END OF invoice.

TYPES : BEGIN OF invoice_e, " For Export
          description      TYPE char255,
          unit_type        TYPE char255,
          weight_unit_type TYPE char255,
          internal_code    TYPE char255,
          quantity         TYPE p DECIMALS 5,
          weight_quantity  TYPE p DECIMALS 5,
          item_code        TYPE string,
          posnr            TYPE posnr,
          numtp            TYPE numtp,
        END OF invoice_e.

DATA : items      TYPE TABLE OF invoice,
       item       TYPE invoice,
       iline      LIKE LINE OF wa_doc-invoice_lines,
       knumv      TYPE knumv, "CONDITION NUMBER
       kurrf      TYPE kurrf, "EXCHANGE RATE
       it_pricing TYPE TABLE OF konv WITH HEADER LINE,
       wa_pricing TYPE konv,
       posnr      TYPE posnr,
       category   TYPE char1,
       etax       LIKE LINE OF iline-taxable_items,
       taxtot     LIKE LINE OF wa_doc-tax_totals,
*       SIGNATURE LIKE LINE OF WA_DOC-SIGNATURES,
       netwr      TYPE netwr,
       null       TYPE c VALUE '-'.
DATA : items_e TYPE TABLE OF invoice_e, " for export
       item_e  TYPE invoice_e,
       iline_e LIKE LINE OF WA_DOC_Export-invoice_lines.

DATA: lr_vk       TYPE RANGE OF vkbur,
      lt_usvalues TYPE TABLE OF usvalues.

DATA : w_temp_PRICING  LIKE it_pricing.
DATA : L_vbelv_temp TYPE vbfa-vbelv.
DATA : L_ADRNR_temp TYPE vbpa-adrnr.
DATA: L_KUNNR_temp TYPE vbpa-kunnr.

"""23-12-2022"""
DATA : L_NETWR_ch TYPE vbrk-netwr.
"""23-12-2022"""


DATA : Ls_cust_numbers TYPE zsd_cust_numbers.
