*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZPP_DISPO2
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZPP_DISPO2          .

  PERFORM TABLEPROC.

ENDFUNCTION.
