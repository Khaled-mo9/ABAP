*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFI0
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFI0                .

  PERFORM TABLEPROC.

ENDFUNCTION.
