*&---------------------------------------------------------------------*
*&  Include           ZSDI_EINV_EINVOICE_ALV
*&---------------------------------------------------------------------*

** POPULATE FIELDCATALOG
FORM POPULATE_FIELDCAT USING FIELDNAME TYPE LVC_FNAME TEXT TYPE SCRTEXT_L ICON TYPE LVC_ICON.
  WA_FIELDCAT-FIELDNAME = FIELDNAME.
  WA_FIELDCAT-SCRTEXT_L = TEXT.
  WA_FIELDCAT-ICON = ICON.

  APPEND WA_FIELDCAT TO IT_FIELDCAT.
  CLEAR WA_FIELDCAT.
ENDFORM.

* BUILD FIELD CATALOG.
FORM BUILD_FIELDCAT.
  CLEAR IT_FIELDCAT.
  PERFORM POPULATE_FIELDCAT USING 'ICON_D' 'Status' 'X'.
  PERFORM POPULATE_FIELDCAT USING 'VBELN' 'Invoice number' ''.
  PERFORM POPULATE_FIELDCAT USING 'BUKRS' 'Company Code' ''.
  PERFORM POPULATE_FIELDCAT USING 'BUTXT' 'Issuer Company' ''.
  PERFORM POPULATE_FIELDCAT USING 'KUNRG' 'Customer #' ''.
  PERFORM POPULATE_FIELDCAT USING 'WAERK' 'Currency' ''.
  PERFORM POPULATE_FIELDCAT USING 'IDNUMBER' 'Customer Tax ID' ''.
  PERFORM POPULATE_FIELDCAT USING 'NAME1' 'Customer Name' ''.
  PERFORM POPULATE_FIELDCAT USING 'DOC_DESC' 'Document Description' ''.
  PERFORM POPULATE_FIELDCAT USING 'DOCUMENT_TYPE' 'Document Type' ''.
  PERFORM POPULATE_FIELDCAT USING 'COUNTRY' 'Country' ''.
  PERFORM POPULATE_FIELDCAT USING 'STATUS' 'Status' ''.
  PERFORM POPULATE_FIELDCAT USING 'UUID' 'UUID' ''.
  PERFORM POPULATE_FIELDCAT USING 'SUBMISSIONID' 'Submission' ''.
  PERFORM POPULATE_FIELDCAT USING 'SALES_TOTAL' 'Sales Total' ''.
  PERFORM POPULATE_FIELDCAT USING 'NET_TOTAL' 'Net Total' ''.
  PERFORM POPULATE_FIELDCAT USING 'TAX' 'Taxes' ''.
  PERFORM POPULATE_FIELDCAT USING 'TOTAL' 'Total' ''.
  PERFORM POPULATE_FIELDCAT USING 'DISCOUNT' 'Discount' ''.
  PERFORM POPULATE_FIELDCAT USING 'EXTRA_DISCOUNT' 'Extra Discount' ''.
  PERFORM POPULATE_FIELDCAT USING 'FKDAT' 'Billing Date' ''.
  PERFORM POPULATE_FIELDCAT USING 'ERDAT' 'Creation Date' ''.
*  PERFORM POPULATE_FIELDCAT USING 'ERZET' 'Creation Time' ''. " added 10-03-2023
  PERFORM POPULATE_FIELDCAT USING 'SUBMISSION_DATE' 'Submission Date' ''.
ENDFORM.


"""""""' DISPLAY ALV OUTPUT .
FORM DISPLAY_ALV.
  LAYOUT-SEL_MODE = 'A'.
  LAYOUT-BOX_FNAME = 'SELCT'.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY_LVC'
    EXPORTING
      I_CALLBACK_PROGRAM       = SY-REPID
      I_CALLBACK_PF_STATUS_SET = 'STATUSBAR'
      I_CALLBACK_USER_COMMAND  = 'UCOMM'
*     I_CALLBACK_TOP_OF_PAGE   = 'HEADER'
      IT_FIELDCAT_LVC          = IT_FIELDCAT
      IS_LAYOUT_LVC            = LAYOUT
    TABLES
      T_OUTTAB                 = IT
    EXCEPTIONS
      PROGRAM_ERROR            = 1
      OTHERS                   = 2.
ENDFORM.


FORM STATUSBAR USING RT_EXTAB TYPE SLIS_T_EXTAB.
  SET PF-STATUS 'ZSD_STATUSBAR' EXCLUDING RT_EXTAB."
ENDFORM.

FORM UCOMM USING R_UCOMM LIKE SY-UCOMM
RS_SELFIELD TYPE SLIS_SELFIELD.

  CASE SY-UCOMM.
    WHEN 'SUBMIT'.

      LOOP AT IT INTO WA WHERE SELCT IS NOT INITIAL.
        TRANSLATE WA-STATUS TO UPPER CASE.
        IF ( WA-STATUS IS INITIAL OR  WA-STATUS = 'INVALID' or WA-STATUS = 'VALIDATION ERROR' or WA-STATUS = 'TOKEN' ) AND WA-FKSTO IS INITIAL. " ESRAA CHANGE STATUS
          PERFORM FILL_JSON.

*          CASE SY-MANDT.
*            WHEN '300'.
*              URL = |https://id.eta.gov.eg/connect/token|.
*            WHEN OTHERS.
*              URL = |https://id.preprod.eta.gov.eg/connect/token|.
*          ENDCASE.
          CASE SY-SYSID.
            WHEN 'E11'.
              URL = |https://id.eta.gov.eg/connect/token|.
            WHEN OTHERS.
              URL = |https://id.preprod.eta.gov.eg/connect/token|.
          ENDCASE.
          PERFORM GET_TOKEN USING URL.

*          URL = 'http://172.19.4.13:3333/signature'. "  10.0.5.5:3333
          URL = 'http://172.28.4.14:3333/signature'. "  10.0.5.5:3333
          PERFORM GET_SIGNATURE USING URL.
          IF ST_CODE <> '404'.

*            CASE SY-MANDT.
*              WHEN '300'.
*                URL = |https://api.invoicing.eta.gov.eg/api/v1.0/documentsubmissions|.
*              WHEN OTHERS.
*                URL = |https://api.preprod.invoicing.eta.gov.eg/api/v1.0/documentsubmissions|.
*            ENDCASE.
            CASE SY-SYSID.
             WHEN 'E11'.
                URL = |https://api.invoicing.eta.gov.eg/api/v1.0/documentsubmissions|.
              WHEN OTHERS.
                URL = |https://api.preprod.invoicing.eta.gov.eg/api/v1.0/documentsubmissions|.
            ENDCASE.

            PERFORM SUBMIT_INVOICE USING URL.
          ELSE.
            WA-ICON_D = ICON_LED_RED.
            INVOICE-STATUS = WA-STATUS = 'TOKEN'.
            INVOICE-VBELN  = WA-VBELN.
            PERFORM INS_UPD.
          ENDIF.
          MODIFY IT FROM WA.
        ELSE.
          IF WA-FKSTO IS NOT INITIAL.
            MESSAGE |This invoice| && WA-VBELN && |is already cancelled from SAP| TYPE 'I'.
          ELSE.
            MESSAGE |This invoice| && WA-VBELN && |is already submitted| TYPE 'I'.
          ENDIF.
        ENDIF.
      ENDLOOP.

    WHEN 'CANCEL'.

      LOOP AT IT INTO WA WHERE SELCT IS NOT INITIAL.
        TRANSLATE WA-STATUS TO UPPER CASE.
        IF WA-STATUS = 'VALID'.

*          CASE SY-MANDT.
*            WHEN '300'.
*              URL = |https://id.eta.gov.eg/connect/token|.
*            WHEN OTHERS.
*              URL = |https://id.preprod.eta.gov.eg/connect/token|.
*          ENDCASE.
          CASE SY-SYSID.
            WHEN 'E11'.
              URL = |https://id.eta.gov.eg/connect/token|.
            WHEN OTHERS.
              URL = |https://id.preprod.eta.gov.eg/connect/token|.
          ENDCASE.
          PERFORM GET_TOKEN USING URL.

*          CASE SY-MANDT.
*            WHEN '300'.
*              URL = |https://api.invoicing.eta.gov.eg/api/v1.0/documents/state/| && WA-UUID && |/state|.
*            WHEN OTHERS.
*              URL = |https://api.preprod.invoicing.eta.gov.eg/api/v1.0/documents/state/| && WA-UUID && |/state|.
*          ENDCASE.
          CASE SY-SYSID.
            WHEN 'E11'.
              URL = |https://api.invoicing.eta.gov.eg/api/v1.0/documents/state/| && WA-UUID && |/state|.
            WHEN OTHERS.
              URL = |https://api.preprod.invoicing.eta.gov.eg/api/v1.0/documents/state/| && WA-UUID && |/state|.
          ENDCASE.
          PERFORM CANCEL_INVOICE USING URL.
          MODIFY IT FROM WA.
        ELSE.
          MESSAGE |This invoice| && WA-VBELN && |is not submitted| TYPE 'I'.
        ENDIF.
      ENDLOOP.

    WHEN 'OVERVIEW'.
      LOOP AT IT INTO WA WHERE SELCT IS NOT INITIAL.
        "IF WA-STATUS IS NOT INITIAL.
        IF WA-uuid IS NOT INITIAL . " ESRAA ADDED
*          CASE SY-MANDT.
*            WHEN '300'.
*              URL = |https://id.eta.gov.eg/connect/token|.
*            WHEN OTHERS.
*              URL = |https://id.preprod.eta.gov.eg/connect/token|.
*          ENDCASE.
          CASE SY-SYSID.
            WHEN 'E11'.
              URL = |https://id.eta.gov.eg/connect/token|.
            WHEN OTHERS.
              URL = |https://id.preprod.eta.gov.eg/connect/token|.
          ENDCASE.
          PERFORM GET_TOKEN USING URL.

*          CASE SY-MANDT.
*            WHEN '300'.
*              URL = |https://api.invoicing.eta.gov.eg/api/v1.0/documents/| && WA-UUID && |/details|.
*            WHEN OTHERS.
*              URL = |https://api.preprod.invoicing.eta.gov.eg/api/v1.0/documents/| && WA-UUID && |/details|.
*          ENDCASE.
          CASE SY-SYSID.
            WHEN 'E11'.
              URL = |https://api.invoicing.eta.gov.eg/api/v1.0/documents/| && WA-UUID && |/details|.
            WHEN OTHERS.
              URL = |https://api.preprod.invoicing.eta.gov.eg/api/v1.0/documents/| && WA-UUID && |/details|.
          ENDCASE.
          PERFORM DETAILS_INVOICE USING URL.

          CLEAR INVALIDS.
          LOOP AT DETAILS-VALIDATIONRESULTS-VALIDATIONSTEPS INTO VALIDATION WHERE STATUS = 'Invalid'.
            LOOP AT VALIDATION-ERROR-INNERERROR INTO INNERERROR.
              APPEND INNERERROR TO INVALIDS.
            ENDLOOP.
          ENDLOOP.
            IF INVALIDS IS NOT INITIAL.
            CALL METHOD CL_DEMO_OUTPUT=>DISPLAY_DATA
              EXPORTING
                VALUE = INVALIDS.
              ENDIF.
           MODIFY IT FROM WA.
        ELSE.
          MESSAGE |This invoice| && WA-VBELN && |is not submitted| TYPE 'I'.
        ENDIF.
      ENDLOOP.

  ENDCASE.
  RS_SELFIELD-REFRESH = 'X'.
ENDFORM.


FORM INS_UPD.

  SELECT SINGLE *
    FROM ZSD_INV_INVOICES
    INTO ANY
    WHERE VBELN = WA-VBELN.
  IF SY-SUBRC = 0.
    UPDATE ZSD_INV_INVOICES FROM INVOICE .
  ELSE.
    INSERT INTO ZSD_INV_INVOICES VALUES INVOICE.
  ENDIF.
  CLEAR INVOICE.
ENDFORM.
