FUNCTION-POOL ZFI0                       MESSAGE-ID SV.

  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFI0T00                                . "view rel. data dcl.
