*&---------------------------------------------------------------------*
*&  Include           ZSDI_EINV_EINVOICE_SUBMIT
*&---------------------------------------------------------------------*
FORM get_token USING url TYPE string.
  FREE http_client.
  CLEAR : head_fields , head_field , http_field , http_fields.

  PERFORM call_url USING url CHANGING http_client.


  http_method = |POST|.
  head_field-name = |Authorization|.
  PERFORM get_cl_idsec.
  CONCATENATE 'Basic' cl_idsec INTO head_field-value SEPARATED BY ' '.
  APPEND head_field TO head_fields.
  PERFORM set_header USING http_method head_fields CHANGING http_client.

  http_field-name = |grant_type|.
  http_field-value = |client_credentials|.
  APPEND http_field TO http_fields.
  http_field-name = |scope|.
  http_field-value = |InvoicingAPI|.
  APPEND http_field TO http_fields.
  PERFORM set_form USING http_method http_fields CHANGING http_client.
  PERFORM send_receive USING http_client 'TOKEN'.

ENDFORM.

FORM submit_invoice USING url TYPE string.
  FREE http_client.
  CLEAR : head_fields , head_field , http_field , http_fields.

  PERFORM call_url USING url CHANGING http_client.

  http_method = |POST|.
  head_field-name = |Content-Type|.
  head_field-value = |application/json|.
  APPEND head_field TO head_fields.
  CLEAR head_field.

  head_field-name = |Authorization|.
  CONCATENATE 'Bearer' stoken-access_token INTO head_field-value SEPARATED BY ' '.
  APPEND head_field TO head_fields.

  PERFORM set_header USING http_method head_fields  CHANGING http_client.
  PERFORM set_body USING inv_sign CHANGING http_client.
  PERFORM send_receive USING http_client 'INVOICE'.
ENDFORM.

FORM call_url USING url TYPE string
      CHANGING client TYPE REF TO if_http_client.
*IF URL <> 'http://172.19.4.13:3333/signature'.
  IF url <> 'http://172.28.4.14:3333/signature'.
    CALL METHOD cl_http_client=>create_by_url
      EXPORTING
        url                = url
*       PROXY_HOST         = 'proxy'
*       PROXY_SERVICE      = '3128'
*       SSL_ID             = 'ANONYM'
*       SAP_USERNAME       =
*       SAP_CLIENT         =
      IMPORTING
        client             = client
      EXCEPTIONS
        argument_not_found = 1
        plugin_not_active  = 2
        internal_error     = 3
        OTHERS             = 4.
  ELSE.
    CALL METHOD cl_http_client=>create_by_url
      EXPORTING
        url                = url
*       SAP_USERNAME       =
*       SAP_CLIENT         =
      IMPORTING
        client             = client
      EXCEPTIONS
        argument_not_found = 1
        plugin_not_active  = 2
        internal_error     = 3
        OTHERS             = 4.
  ENDIF.
ENDFORM.

FORM set_header USING method TYPE string
      head_fields TYPE tihttpnvp
  CHANGING client TYPE REF TO if_http_client.

  client->request->set_method(
      method = method
  ).
  client->request->set_header_fields( fields = head_fields ).

ENDFORM.

FORM set_body USING body TYPE string
  CHANGING client TYPE REF TO if_http_client.
  client->request->set_cdata(
    EXPORTING
      data               =  body   " Character data
            ).
ENDFORM.

FORM set_form USING method TYPE string
      fields TYPE tihttpnvp
  CHANGING client TYPE REF TO if_http_client.

  client->request->set_method(
      method = method
  ).
  client->request->set_form_fields( fields = fields ).

ENDFORM.

FORM get_cl_idsec.

  SELECT SINGLE value
    INTO id
    FROM zsd_einv_setting
    WHERE bukrs = wa-bukrs AND key_code = '01'.
  SELECT SINGLE value
    INTO secret
    FROM zsd_einv_setting
    WHERE bukrs = wa-bukrs AND key_code = '02'.
  CONCATENATE id ':' secret INTO cl_idsec.

  cl_idsec = lo_httputil->encode_base64( unencoded = cl_idsec ).

ENDFORM.

FORM send_receive USING client TYPE REF TO if_http_client http_type TYPE string.

  client->send(
*  EXPORTING
*    TIMEOUT                    = CO_TIMEOUT_DEFAULT    " Timeout of Answer Waiting Time
    EXCEPTIONS
      http_communication_failure = 1
      http_invalid_state         = 2
      http_processing_failed     = 3
      http_invalid_timeout       = 4
      OTHERS                     = 5
  ).
  client->receive(
    EXCEPTIONS
      http_communication_failure = 1
      http_invalid_state         = 2
      http_processing_failed     = 3
      OTHERS                     = 4
  ).
  client->response->get_status(
    IMPORTING
      code   = st_code    " HTTP status code
      reason = reason    " HTTP status description
  ).
  response = client->response->get_cdata( ).
  CASE http_type.

    WHEN 'TOKEN'.
      IF st_code = '200'.
        cl_fdt_json=>json_to_data( EXPORTING iv_json = response
        CHANGING ca_data = stoken ).
      ELSE.
        cl_fdt_json=>json_to_data( EXPORTING iv_json = response
        CHANGING ca_data = etoken ).
      ENDIF.

    WHEN 'INVOICE'.
      CLEAR submission.
      response = to_upper( response ).
      cl_fdt_json=>json_to_data( EXPORTING iv_json = response
      CHANGING ca_data = submission ).
      "DOCUMENT ACCEPTED
      IF submission-accepteddocuments IS NOT INITIAL.
        READ TABLE submission-accepteddocuments INTO acc_doc INDEX 1.
        invoice-vbeln          = acc_doc-internalid.
        invoice-submissionid   = wa-submissionid       = submission-submissionid.
        invoice-uuid           = wa-uuid               = acc_doc-uuid.
        invoice-longid         = acc_doc-longid.
        invoice-sales_total    = wa-sales_total        = wa_doc-total_sales_amount.
        invoice-net_total      = wa-net_total          = wa_doc-net_amount.
        invoice-tax            = wa-tax                = taxtot-amount.
        invoice-total          = wa-total              = wa_doc-total_amount.
        invoice-discount       = wa-discount           = wa_doc-total_discount_amount.
        invoice-extra_discount = wa-extra_discount     = wa_doc-extra_discount_amount.
        invoice-created_by     = sy-uname.
        invoice-created_date   = wa-submission_date    = sy-datum.
        invoice-created_time   = sy-uzeit.
        IF wa_doc_export-receiver-type = 'F'.
          invoice-sales_total    = wa-sales_total        = WA_DOC_Export-total_sales_amount.
          invoice-net_total      = wa-net_total          = WA_DOC_Export-net_amount.
          invoice-total          = wa-total              = WA_DOC_Export-total_amount.
          invoice-discount       = wa-discount           = WA_DOC_Export-total_discount_amount.
          invoice-extra_discount = wa-extra_discount     = WA_DOC_Export-extra_discount_amount.
        ENDIF.

        """""""""""""""""""""GET STATUS LOGIC HERE"""""""""""""""""""""""""""""""""""
        WAIT UP TO 10 SECONDS.
*CASE SY-MANDT.
*  WHEN '300'.
*    URL = |https://api.invoicing.eta.gov.eg/api/v1.0/documents/| && WA-UUID && |/details|.
*  WHEN OTHERS.
*    URL = |https://api.preprod.invoicing.eta.gov.eg/api/v1.0/documents/| && WA-UUID && |/details|.
*ENDCASE.
        CASE sy-sysid.
          WHEN 'E11'.
            url = |https://api.invoicing.eta.gov.eg/api/v1.0/documents/| && wa-uuid && |/details|.
          WHEN OTHERS.
            url = |https://api.preprod.invoicing.eta.gov.eg/api/v1.0/documents/| && wa-uuid && |/details|.
        ENDCASE.

        """"""""""""""""

        PERFORM ins_upd.
        PERFORM details_invoice USING url.
*IF DETAILS-STATUS = 'Valid'.
*  INVOICE-STATUS        = WA-STATUS             = 'VALID'.
*  WA-ICON_D = ICON_LED_GREEN.
*ELSEIF DETAILS-STATUS = 'Invalid'.
*  INVOICE-STATUS        = WA-STATUS             = 'INVALID'.
*  WA-ICON_D = ICON_LED_YELLOW.
*elseif INVOICE-UUID is not INITIAL and DETAILS-STATUS is INITIAL . " not valid or invalid and submitted / ESRAA ADDED
*   INVOICE-STATUS        = WA-STATUS             = 'SUBMITTED'.
*   WA-ICON_D = ICON_DOCUMENT.
*ENDIF.
*INSERT INTO ZSD_INV_INVOICES VALUES INVOICE.

        "DOCUMENT REJECTED
      ELSEIF submission-rejecteddocuments IS NOT INITIAL.
        READ TABLE submission-rejecteddocuments INTO rej_doc INDEX 1.
        invoice-vbeln = wa-vbeln.
        wa-icon_d = icon_led_red.
        invoice-status = wa-status = rej_doc-error-message.
        READ TABLE rej_doc-error-details INTO detail_error INDEX 1.
        MESSAGE detail_error-message TYPE 'I'.
        CLEAR : wa-uuid , wa-submissionid , invoice-uuid , invoice-submissionid.
        PERFORM ins_upd.
      ENDIF.

    WHEN 'SIGNATURE'.
      IF st_code = '200' OR st_code = '202'.
        inv_sign = response.
      ELSE.
        CLEAR inv_sign.
      ENDIF.

    WHEN 'CANCEL'.
      SELECT SINGLE *
        FROM zsd_inv_invoices
        INTO invoice
        WHERE vbeln = wa-vbeln.

      wa-icon_d            = icon_cancel.
      invoice-status       = wa-status      = 'CANCEL'.
      invoice-created_by   = sy-uname.
      invoice-created_date = sy-datum.
      invoice-created_time = sy-uzeit.
      UPDATE zsd_inv_invoices FROM invoice .

    WHEN 'DETAILS'.
      CLEAR details.
      CALL METHOD /ui2/cl_json=>deserialize
        EXPORTING
          json = response
*         JSONX            =
*         PRETTY_NAME      = PRETTY_MODE-NONE
*         ASSOC_ARRAYS     = C_BOOL-FALSE
*         ASSOC_ARRAYS_OPT = C_BOOL-FALSE
*         NAME_MAPPINGS    =
*         CONVERSION_EXITS = C_BOOL-FALSE
        CHANGING
          data = details.
      "ESRAA ADDED
      TRANSLATE details-status TO UPPER CASE.
      SELECT SINGLE * FROM zsd_inv_invoices INTO CORRESPONDING FIELDS OF invoice
        WHERE vbeln = wa-vbeln.
      invoice-vbeln          = wa-vbeln ."ACC_DOC-INTERNALID.
      invoice-submissionid   = wa-submissionid      .
      invoice-uuid           = wa-uuid              .
      "INVOICE-LONGID         = ACC_DOC-LONGID.
      IF wa_doc-total_sales_amount IS NOT INITIAL. " overview after submit.
        invoice-sales_total    = wa-sales_total        = wa_doc-total_sales_amount.
        invoice-net_total      = wa-net_total          = wa_doc-net_amount.
        invoice-tax            = wa-tax                = taxtot-amount.
        invoice-total          = wa-total              = wa_doc-total_amount.
        invoice-discount       = wa-discount           = wa_doc-total_discount_amount.
        invoice-extra_discount = wa-extra_discount     = wa_doc-extra_discount_amount.
        IF wa_doc_export-receiver-type = 'F'.
          invoice-sales_total    = wa-sales_total        = WA_DOC_Export-total_sales_amount.
          invoice-net_total      = wa-net_total          = WA_DOC_Export-net_amount.
          invoice-total          = wa-total              = WA_DOC_Export-total_amount.
          invoice-discount       = wa-discount           = WA_DOC_Export-total_discount_amount.
          invoice-extra_discount = wa-extra_discount     = WA_DOC_Export-extra_discount_amount.
        ENDIF.

      ENDIF.
      invoice-status = wa-status      = details-status .
      invoice-created_by   = sy-uname.
      invoice-created_date = sy-datum.
      invoice-created_time = sy-uzeit.

      "----"
      IF details-status = 'Valid'.
        invoice-status        = wa-status             = 'VALID'.
        wa-icon_d = icon_led_green.
      ELSEIF details-status = 'Invalid'.
        invoice-status        = wa-status             = 'INVALID'.
        wa-icon_d = icon_led_yellow.
      ELSEIF invoice-uuid IS NOT INITIAL AND details-status IS INITIAL . " not valid or invalid and submitted / ESRAA ADDED
        invoice-status        = wa-status             = 'SUBMITTED'.
        wa-icon_d = icon_document.
      ENDIF.
      UPDATE zsd_inv_invoices FROM invoice .
      CLEAR invoice.


*cl_fdt_json=>json_to_data( EXPORTING iv_json = RESPONSE
*CHANGING CA_DATA = DETAILS ).

  ENDCASE.


ENDFORM.
